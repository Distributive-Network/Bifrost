# MODULES

# python standard library
import codecs
import inspect
import re
import zlib

# pypi modules
import cloudpickle

# PROGRAM

def input_encoder(input_data):

    data_encoded = codecs.encode( input_data, 'base64' ).decode()

    return data_encoded

def output_decoder(output_data):

    data_decoded = codecs.decode( output_data.encode(), 'base64' )

    return data_decoded

def pickle_jar(input_data, compress_data = False):

    import bifrost

    if hasattr(cloudpickle, 'register_pickle_by_value'):
        cloudpickle.register_pickle_by_value(bifrost)

    data_pickled = cloudpickle.dumps( input_data )
    if compress_data == True:
        data_compressed = zlib.compress( data_pickled )
        data_encoded = __input_encoder( data_compressed )
    else:
        data_encoded = __input_encoder( data_pickled )

    return data_encoded

def unpickle_jar(output_data, decompress_data = False):

    data_decoded = __output_decoder( output_data )
    if decompress_data == True:
        data_decompressed = zlib.decompress( data_decoded )
        data_unpickled = cloudpickle.loads( data_decompressed )
    else:
        data_unpickled = cloudpickle.loads( data_decoded )

    return data_unpickled

def function_writer(function):

    try:
        # function code is locally retrievable source code
        function_name = function.__name__
        function_code = inspect.getsource(function)
    except: # OSError
        try:
            # function code is in a .py file in the current directory
            function_name = function
            function_code = Path(function_name).read_text()
        except: # FileNotFoundError
            # function code is already represented as a string
            function_name = re.findall("def (.+?)\s?\(", function)[0]
            function_code = function
    finally:
        return {'name': function_name, 'code': function_code}

